Pre requisites :

1. JDK 8 or later
2. Apache Maven latest
3. Mysql server

Steps:

Create a database xl_dump

import model.csv file into table "model"

In src/main/resources/application.properties file 

 -> Change Mysql root user password of your choice

Open terminal/command prompt and navigate to root of project folder

# The below command will start tomcat server on port 8000 (you can configure it in properties file)

“mvn spring-boot:run”
