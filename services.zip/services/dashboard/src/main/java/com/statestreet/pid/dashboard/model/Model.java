package com.statestreet.pid.dashboard.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the model database table.
 * 
 */
@Entity
@NamedQuery(name="Model.findAll", query="SELECT m FROM Model m")
public class Model implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="AS_OF_TMS")
	private Date asOfTms;

	@Column(name="AVG_PROCESSTIME_DECIMAL")
	private double avgProcesstimeDecimal;

	@Lob
	@Column(name="AVG_PROCESSTIME_VALUE")
	private String avgProcesstimeValue;

	private int client_Identifier;

	@Lob
	private String decreasing_Trend;

	@Column(name="FUND_CNT")
	private int fundCnt;

	@Column(name="growth_rate")
	private double growthRate;

	@Lob
	private String increasing_Trend;

	private double LCL_Individual;

	@Column(name="LCL_MR")
	private int lclMr;

	private double mr;

	private double MRbar;

	private double MRchange;

	private int MRchange_value;

	@Column(name="PCS_STEP_CFG_KY")
	private int pcsStepCfgKy;

	private double UCL_Individual;

	@Column(name="UCL_MR")
	private double uclMr;

	private double xbar;

	private double xchange;

	private int xchange_value;

	private int xchange_value_grp;

	public Model() {
	}

	public Date getAsOfTms() {
		return this.asOfTms;
	}

	public void setAsOfTms(Date asOfTms) {
		this.asOfTms = asOfTms;
	}

	public double getAvgProcesstimeDecimal() {
		return this.avgProcesstimeDecimal;
	}

	public void setAvgProcesstimeDecimal(double avgProcesstimeDecimal) {
		this.avgProcesstimeDecimal = avgProcesstimeDecimal;
	}

	public String getAvgProcesstimeValue() {
		return this.avgProcesstimeValue;
	}

	public void setAvgProcesstimeValue(String avgProcesstimeValue) {
		this.avgProcesstimeValue = avgProcesstimeValue;
	}

	public int getClient_Identifier() {
		return this.client_Identifier;
	}

	public void setClient_Identifier(int client_Identifier) {
		this.client_Identifier = client_Identifier;
	}

	public String getDecreasing_Trend() {
		return this.decreasing_Trend;
	}

	public void setDecreasing_Trend(String decreasing_Trend) {
		this.decreasing_Trend = decreasing_Trend;
	}

	public int getFundCnt() {
		return this.fundCnt;
	}

	public void setFundCnt(int fundCnt) {
		this.fundCnt = fundCnt;
	}

	public double getGrowthRate() {
		return this.growthRate;
	}

	public void setGrowthRate(double growthRate) {
		this.growthRate = growthRate;
	}

	public String getIncreasing_Trend() {
		return this.increasing_Trend;
	}

	public void setIncreasing_Trend(String increasing_Trend) {
		this.increasing_Trend = increasing_Trend;
	}

	public double getLCL_Individual() {
		return this.LCL_Individual;
	}

	public void setLCL_Individual(double LCL_Individual) {
		this.LCL_Individual = LCL_Individual;
	}

	public int getLclMr() {
		return this.lclMr;
	}

	public void setLclMr(int lclMr) {
		this.lclMr = lclMr;
	}

	public double getMr() {
		return this.mr;
	}

	public void setMr(double mr) {
		this.mr = mr;
	}

	public double getMRbar() {
		return this.MRbar;
	}

	public void setMRbar(double MRbar) {
		this.MRbar = MRbar;
	}

	public double getMRchange() {
		return this.MRchange;
	}

	public void setMRchange(double MRchange) {
		this.MRchange = MRchange;
	}

	public int getMRchange_value() {
		return this.MRchange_value;
	}

	public void setMRchange_value(int MRchange_value) {
		this.MRchange_value = MRchange_value;
	}

	public int getPcsStepCfgKy() {
		return this.pcsStepCfgKy;
	}

	public void setPcsStepCfgKy(int pcsStepCfgKy) {
		this.pcsStepCfgKy = pcsStepCfgKy;
	}

	public double getUCL_Individual() {
		return this.UCL_Individual;
	}

	public void setUCL_Individual(double UCL_Individual) {
		this.UCL_Individual = UCL_Individual;
	}

	public double getUclMr() {
		return this.uclMr;
	}

	public void setUclMr(double uclMr) {
		this.uclMr = uclMr;
	}

	public double getXbar() {
		return this.xbar;
	}

	public void setXbar(double xbar) {
		this.xbar = xbar;
	}

	public double getXchange() {
		return this.xchange;
	}

	public void setXchange(double xchange) {
		this.xchange = xchange;
	}

	public int getXchange_value() {
		return this.xchange_value;
	}

	public void setXchange_value(int xchange_value) {
		this.xchange_value = xchange_value;
	}

	public int getXchange_value_grp() {
		return this.xchange_value_grp;
	}

	public void setXchange_value_grp(int xchange_value_grp) {
		this.xchange_value_grp = xchange_value_grp;
	}

}